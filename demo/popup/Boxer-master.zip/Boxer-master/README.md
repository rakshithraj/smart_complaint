<h2>Development of this plugin has ended. Please upgrade to the new <a href="http://formstone.it">Formstone</a>.</h2><br> 

<a href="http://gruntjs.com" target="_blank"><img src="https://cdn.gruntjs.com/builtwith.png" alt="Built with Grunt"></a> 
# Boxer 

A jQuery plugin for displaying images, videos or content in a modal overlay. Part of the Formstone Library. 

- [Demo](http://classic.formstone.it/components/Boxer/demo/index.html) 
- [Documentation](http://classic.formstone.it/boxer/) 

#### Bower Support 
`bower install Boxer` 